package enums;

public enum CategoriaProduto {
    ALIMENTO,
    BEBIDA,
    HIGIENE,
    LIMPEZA,
    ELETRONICO,
    ROUPA,
    OUTRO
}
